package com.example.bt;

import android.support.v4.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements AFragment.OnFragmentInteractionListener{

    //private TextView mTextMessage;
    Fragment device;
    Fragment music;
    Fragment phone;
    FragmentManager mFragmentManager;
    void swtichFragment(Fragment fg){
        mFragmentManager.beginTransaction().replace(R.id.fragment, fg).commit();
    }
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_device:
                   // mTextMessage.setText(R.string.title_device);
                    if(device==null)
                        device = new DeviceFragment();//AFragment.newInstance("device","1");
                    swtichFragment(device);
                    return true;
                case R.id.navigation_music:
                    //mTextMessage.setText(R.string.title_music);
                    if(music==null)
                        music = new MusicFragment();//AFragment.newInstance("music","2");
                    swtichFragment(music);
                    return true;
                case R.id.navigation_phone:
                    //mTextMessage.setText(R.string.title_phone);
                    if(phone==null)
                        phone = new PhoneFragment();//AFragment.newInstance("phone","3");
                    swtichFragment(phone);
                    return true;
            }
            return false;
        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        int[][] states = new int[][]{
                new int[]{-android.R.attr.state_checked},
                new int[]{android.R.attr.state_checked}
        };
        int[] colors = new int[]{Color.BLACK,Color.GRAY};
        ColorStateList csl = new ColorStateList(states, colors);
        navigation.setItemIconTintList(csl);
        navigation.setItemTextColor(csl);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        mFragmentManager = getSupportFragmentManager();
        //Fragment fg = mFragmentManager.findFragmentById(R.id.fragment);
        //mFragmentManager.beginTransaction().remove(fg).commit();
        if(device==null)
            device = new DeviceFragment();
        swtichFragment(device);
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
